//
//  ViewController.swift
//  Apren.de
//
//  Created by Aldo Trejo Antonio on 10/03/17.
//  Copyright © 2017 Aldo Trejo Antonio. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var web: UIWebView!

    override func viewDidLoad() {
        let alertController = UIAlertController(title: "Estas demasiado lejos", message: "Acercate a ese", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "ok", style: .default, handler: nil)
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion:nil)
        
        web.loadRequest(URLRequest(url: URL(string: "http://bytemex.net/aprende")!))
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

