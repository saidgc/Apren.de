

<?php
/*
 _______  _        _______  _        ______   _______  _______             ______           _________ _______  _______  _______          
(  ___  )( \      (  ___  )( (    /|(  __  \ (  ____ )(  ___  )           (  ___ \ |\     /|\__   __/(  ____ \(       )(  ____ \|\     /|
| (   ) || (      | (   ) ||  \  ( || (  \  )| (    )|| (   ) |           | (   ) )( \   / )   ) (   | (    \/| () () || (    \/( \   / )
| (___) || |      | |   | ||   \ | || |   ) || (____)|| (___) |   _____   | (__/ /  \ (_) /    | |   | (__    | || || || (__     \ (_) / 
|  ___  || |      | |   | || (\ \) || |   | ||     __)|  ___  |  (_____)  |  __ (    \   /     | |   |  __)   | |(_)| ||  __)     ) _ (  
| (   ) || |      | |   | || | \   || |   ) || (\ (   | (   ) |           | (  \ \    ) (      | |   | (      | |   | || (       / ( ) \ 
| )   ( || (____/\| (___) || )  \  || (__/  )| ) \ \__| )   ( |           | )___) )   | |      | |   | (____/\| )   ( || (____/\( /   \ )
|/     \|(_______/(_______)|/    )_)(______/ |/   \__/|/     \|           |/ \___/    \_/      )_(   (_______/|/     \|(_______/|/     \|

Instrucciones:

el api Debe recibir todas las variables que pide, de lo contrario los cálculos no serán correctos, hay diferentes maneras de pasar los parámetros, eso lo dejo a su consideración, Se tocan los puntos mas importantes del cerebro que se encargan de procesar el conocimientos y retener la información, dadle un buen uso y Happy hunger games
 
  */                                                                                                                                                       
 //El Tiempo va en segundos        
$vuelta=$vuelta+1;
$total=10;
//datos
$TiempoD1="4";
$edadD1="5";
$ComplejidadD1="2";
$intentosD1="2";

$TiempoD2="4";
$edadD2="5";
$ComplejidadD2="1";
$intentosD2="2";


$Tipo=$res['Tipo'];
$Tipo="3";
//1=Lobulo_parental
//2=Hipocampo
//3=Lobulo_temporal
//Periodos criticos

//prueba
$Tiempo="40";
$edad="5";
$Complejidad="2";
$intentos="5";

$Lobulo_Parietal="";
$Hipocampo="";
$LobuloTemporal="";
$PeriodosCriticos="";   
//lobulo parietal




                                                                                                                                         
                                                                                                                                         
/*                                                                                                                                         
$Tiempo=$res['Tiempo'];
$edad=$res['edad'];
$Complejidad=$res['Complejidad'];
$intentos=$res['Intentos'];
$Lobulo_Parietal=$res['lobulop'];
$Hipocampo=$res['Hipocampo'];
$LobuloTemporal=$res['LobuloTemporal'];
$PeriodosCriticos=$res['PeriodosCriticos'];
*/


if($vuelta>=2){
//Periodos Criticos
	if($intentos==10){
		$Lintentos="100";
	}else{
  		$Lintentos=((Lintentos/100)*100);
	}
	//echo $vuelta;
} else{
	if($Tipo==1){
		if($intentos==1){
			$Lobulo_Parietal=(($Tiempo*$edad)/$Complejidad);
			$estimado=($TiempoD1*$edadD1/($ComplejidadD2));
			$Total=$Lobulo_Parietal-$estimado;
		}else if($intentos==2){
			$Lobulo_Parietal=((($Tiempo*$edad)/$Complejidad)-10);
			$estimado=($TiempoD1*$edadD1/($ComplejidadD2));
			$Total=$Lobulo_Parietal-$estimado;
		}else if($intentos==3){
			$Lobulo_Parietal=((($Tiempo*$edad)/$Complejidad)-20);
			$estimado=($Tiem4oD1*$edadD1/($ComplejidadD2));
			$Total=$Lobulo_Parietal-$estimado;
		}else if($intentos==4){
			$Lobulo_Parietal=((($Tiempo*$edad)/$Complejidad)-30);
			$estimado=($TiempoD1*$edadD1/($ComplejidadD2));
			$Total=$Lobulo_Parietal-$estimado;
		}else if($intentos==5){
			$Lobulo_Parietal=((($Tiempo*$edad)/$Complejidad)-40);
			$estimado=($TiempoD1*$edadD1/($ComplejidadD2));
			$Total=$Lobulo_Parietal-$estimado;
		}
//LobuloParental
	}else if($Tipo==2){
if ($intentos==1){
		$intentos=$intentos*10;
}else if($intentos==2){
$intentos=$intentos*10;
}else if($intentos==3){
	$intentos=$intentos*10;
}else if($intentos==4){
	$intentos=$intentos*10;
}else if($intentos==5){
	$intentos=$intentos*10;
}else if($intentos==6){
	$intentos=$intentos*10;
}else if($intentos==7){
	$intentos=$intentos*10;
}else if($intentos==8){
	$intentos=$intentos*10;
}else if($intentos==9){
	$intentos=$intentos*10;
}else if($intentos==10){
	$intentos=$intentos*10;
}
//Hipocampo  recuerdo a largo plazo 
	}else if($Tipo==3){
$total3=($intentos-$Total);
//Lobulo_temporal
	}
}

echo $Total;
echo $total3;
echo 'hola';


?>