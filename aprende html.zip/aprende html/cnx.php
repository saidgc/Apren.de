<?php
error_reporting(0);
$user="u909825841_apren";
$pass="muJaLe";
$host="127.0.0.1";
$db="u909825841_apren";
$con=mysql_connect($host,$user,$pass)or die("Error 1");
mysql_select_db($db)or die("Error 2");

?>